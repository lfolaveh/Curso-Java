'use strict';

angular.module('javascriptApp.util', []);
